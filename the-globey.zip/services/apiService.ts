
import { initializeApp, FirebaseApp } from "firebase/app";
import { getFirestore, doc, getDoc, setDoc, Firestore } from "firebase/firestore";
import { UserProfile } from '../types';

let app: FirebaseApp | null = null;
let db: Firestore | null = null;

const getUserId = (): string => {
  let id = localStorage.getItem('globey_user_id');
  if (!id) {
    id = 'user_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('globey_user_id', id);
  }
  return id;
};

// Load config from localStorage (set via Settings UI) or use placeholder
const getFirebaseConfig = () => {
  const savedConfig = localStorage.getItem('globey_firebase_config');
  if (savedConfig) {
    try {
      return JSON.parse(savedConfig);
    } catch (e) {
      return null;
    }
  }
  return null;
};

const initFirebase = () => {
  const config = getFirebaseConfig();
  if (config && config.projectId && !config.projectId.includes('globey-adventure')) {
    try {
      app = initializeApp(config);
      db = getFirestore(app);
      return true;
    } catch (e) {
      console.error("Firebase init failed", e);
      return false;
    }
  }
  return false;
};

// Initial attempt
initFirebase();

export const apiService = {
  isConfigured(): boolean {
    return db !== null;
  },

  async saveProfile(profile: UserProfile): Promise<boolean> {
    const userId = getUserId();
    localStorage.setItem('globey_user', JSON.stringify(profile));

    if (!db) return false;

    try {
      const userRef = doc(db, "users", userId);
      await setDoc(userRef, {
        ...profile,
        lastUpdated: new Date().toISOString()
      }, { merge: true });
      return true;
    } catch (error: any) {
      if (error.code === 'permission-denied') {
        console.error("Firestore Permission Denied. Check your Security Rules!");
      }
      return false;
    }
  },

  async loadProfile(): Promise<UserProfile | null> {
    const userId = getUserId();
    
    if (db) {
      try {
        const userRef = doc(db, "users", userId);
        const docSnap = await getDoc(userRef);
        if (docSnap.exists()) {
          const data = docSnap.data() as UserProfile;
          localStorage.setItem('globey_user', JSON.stringify(data));
          return data;
        }
      } catch (error) {
        console.warn("Firebase load failed, using local fallback");
      }
    }

    const saved = localStorage.getItem('globey_user');
    return saved ? JSON.parse(saved) : null;
  }
};
