
import { GoogleGenAI, Type } from "@google/genai";
import { LessonData, SkillType, LearningGoal } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateLessonContent = async (
  regionName: string,
  skill: SkillType,
  goal: LearningGoal,
  questTopic?: string // Specific sub-topic for APUSH quests
): Promise<LessonData> => {
  const isFlagQuiz = skill === SkillType.FLAGS;
  const isHistory = skill === SkillType.APUSH || skill === SkillType.APWH;

  const prompt = `
    You are 'The Globey', a friendly, enthusiastic educational expert.
    Create a fun, engaging mini-lesson and quiz for a user.
    ${isHistory ? `Subject: History - Focus: ${skill}${questTopic ? ` - Specific Sub-topic: ${questTopic}` : ''}` : `Subject: Geography - Region: ${regionName} - Focus: ${skill}`}
    User Goal: ${goal}

    Include:
    1. A catchy title tailored to the specific topic.
    2. A brief, friendly introduction (2-3 sentences).
    3. 4-5 fascinating key facts about this topic.
    4. A 5-question multiple choice quiz.
    ${isFlagQuiz ? "IMPORTANT: Since this is a flag quiz, include a 'countryCode' field for each question. This should be the lowercase ISO 3166-1 alpha-2 code of the country the flag belongs to (e.g., 'us', 'fr', 'jp')." : ""}
    
    Make the tone supportive and educational.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          intro: { type: Type.STRING },
          keyFacts: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          quiz: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                correctAnswer: { type: Type.STRING },
                explanation: { type: Type.STRING },
                countryCode: { type: Type.STRING, description: "lowercase ISO country code, only for flag questions" }
              },
              required: ["question", "options", "correctAnswer", "explanation"]
            }
          }
        },
        required: ["title", "intro", "keyFacts", "quiz"]
      }
    }
  });

  try {
    const data = JSON.parse(response.text);
    return { ...data, skillType: skill };
  } catch (error) {
    console.error("Failed to parse Gemini response", error);
    throw new Error("Globey is having a bit of brain fog! Try again.");
  }
};

export const getPersonalizedHint = async (
  question: string,
  wrongAnswer: string,
  correctAnswer: string
): Promise<string> => {
  const prompt = `
    A student is learning ${question.includes('History') ? 'History' : 'Geography'}. They were asked: "${question}".
    They incorrectly answered: "${wrongAnswer}".
    The correct answer is: "${correctAnswer}".
    
    As 'The Globey' (a friendly globe mascot), provide a short, encouraging, and memorable hint to help them remember the correct answer next time. Don't just give the answer; give a fun mnemonic or association. Max 20 words.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
  });

  return response.text || "Keep exploring, you'll get it next time!";
};
