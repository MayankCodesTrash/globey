
import React from 'react';

interface GlobeyMascotProps {
  message: string;
  isThinking?: boolean;
  emotion?: 'happy' | 'thinking' | 'neutral' | 'oops';
}

const GlobeyMascot: React.FC<GlobeyMascotProps> = ({ message, isThinking, emotion = 'neutral' }) => {
  const MASCOT_URL = "https://i.pinimg.com/1200x/32/df/55/32df5542dbb43e8e846e9720846c2a95.jpg";

  const getEmotionFilter = () => {
    switch(emotion) {
      case 'happy': return 'drop-shadow(0 0 15px rgba(34, 197, 94, 0.4)) brightness(1.1)';
      case 'oops': return 'drop-shadow(0 0 15px rgba(239, 68, 68, 0.4)) saturate(0.8)';
      default: return 'drop-shadow(0 10px 15px rgba(59, 130, 246, 0.2))';
    }
  };

  return (
    <div className="flex flex-col items-center gap-6 w-full px-4 transition-all duration-700 ease-out">
      <div 
        className={`relative transition-transform duration-500 ${emotion === 'happy' ? 'scale-110' : 'scale-100'}`}
        style={{ filter: getEmotionFilter() }}
      >
        <div className="animate-bounce-slow">
           <img 
             src={MASCOT_URL} 
             alt="Globey Mascot" 
             className={`w-32 h-32 md:w-40 md:h-40 object-contain rounded-full border-4 border-white dark:border-slate-700 shadow-lg transition-all duration-500 ${emotion === 'oops' ? 'rotate-12' : 'rotate-0'}`} 
           />
        </div>
        
        {isThinking && (
          <div className="absolute -top-4 -right-4 bg-white dark:bg-slate-800 rounded-full p-3 shadow-2xl animate-pulse border-2 border-blue-100 dark:border-blue-900">
            <span className="text-2xl">💭</span>
          </div>
        )}
        {emotion === 'happy' && (
           <div className="absolute -top-6 -left-4 text-4xl animate-bounce">✨</div>
        )}
      </div>

      <div className="relative group w-full max-w-sm">
        <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-sky-400 rounded-[2rem] blur opacity-25 group-hover:opacity-40 transition duration-1000"></div>
        <div className="relative bg-white dark:bg-slate-800 p-6 md:p-8 rounded-[2rem] shadow-2xl border-2 border-blue-50 dark:border-slate-700 text-center transform transition-transform duration-300">
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-white dark:bg-slate-800 border-t-2 border-l-2 border-blue-50 dark:border-slate-700 rotate-45"></div>
          <p className="text-lg md:text-xl font-bold text-slate-800 dark:text-slate-100 leading-relaxed font-quicksand">
            {message}
          </p>
        </div>
      </div>
    </div>
  );
};

export default GlobeyMascot;
