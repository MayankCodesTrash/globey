
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { apiService } from '../services/apiService';

interface SettingsProps {
  user: UserProfile;
  onUpdate: (updatedUser: UserProfile) => void;
}

const Settings: React.FC<SettingsProps> = ({ user, onUpdate }) => {
  const [configText, setConfigText] = useState(localStorage.getItem('globey_firebase_config') || '');
  const [showConfig, setShowConfig] = useState(false);

  const toggleTheme = () => {
    onUpdate({ ...user, theme: user.theme === 'light' ? 'dark' : 'light' });
  };

  const saveFirebaseConfig = () => {
    try {
      // Basic validation: try to parse it if it's a JSON block
      const cleanJson = configText.trim().replace(/^const firebaseConfig = /, '').replace(/;$/, '');
      const parsed = configText.includes('{') ? JSON.parse(cleanJson) : null;
      
      if (parsed && parsed.projectId) {
        localStorage.setItem('globey_firebase_config', JSON.stringify(parsed));
        alert("Firebase config saved! Restarting app to apply...");
        window.location.reload();
      } else {
        alert("Invalid config. Please paste the JSON object from Firebase Console.");
      }
    } catch (e) {
      alert("Error parsing config. Make sure it's valid JSON.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-6 pb-32 page-enter">
      <div className="max-w-xl mx-auto space-y-10 mt-8">
        <h2 className="text-4xl font-fredoka text-slate-900 dark:text-white">Settings</h2>

        <div className="bg-white dark:bg-slate-800 p-8 rounded-[3rem] shadow-xl border border-slate-50 dark:border-slate-700 space-y-8">
          
          {/* Cloud Storage Status */}
          <section className="space-y-4">
             <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest">Cloud Sync</h3>
             <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700 rounded-3xl">
                <div className="flex items-center gap-4">
                   <span className="text-2xl">{apiService.isConfigured() ? '☁️' : '📴'}</span>
                   <div>
                     <p className="font-bold text-slate-800 dark:text-white">
                       {apiService.isConfigured() ? 'Firebase Connected' : 'Local Only Mode'}
                     </p>
                     <p className="text-[10px] text-slate-400 font-bold uppercase">
                       {apiService.isConfigured() ? 'Progress is backed up' : 'Progress saved on this device only'}
                     </p>
                   </div>
                </div>
                <button 
                  onClick={() => setShowConfig(!showConfig)}
                  className="px-4 py-2 bg-blue-500 text-white text-xs font-black rounded-xl shadow-lg shadow-blue-500/20"
                >
                  {showConfig ? 'Hide' : 'Setup'}
                </button>
             </div>

             {showConfig && (
               <div className="p-6 bg-slate-100 dark:bg-slate-900 rounded-3xl space-y-4 animate-in slide-in-from-top-2">
                 <p className="text-xs text-slate-500 font-bold">
                   Paste your <code>firebaseConfig</code> object from the Firebase Console:
                 </p>
                 <textarea 
                   className="w-full h-32 p-4 text-xs font-mono bg-white dark:bg-slate-800 rounded-2xl border-2 border-slate-200 dark:border-slate-700 dark:text-blue-300"
                   placeholder='{ "apiKey": "...", "projectId": "...", ... }'
                   value={configText}
                   onChange={(e) => setConfigText(e.target.value)}
                 />
                 <button 
                   onClick={saveFirebaseConfig}
                   className="w-full p-4 bg-slate-900 dark:bg-blue-600 text-white rounded-2xl font-black text-sm"
                 >
                   Save & Sync Progress
                 </button>
               </div>
             )}
          </section>

          <section className="space-y-4">
             <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest">Appearance</h3>
             <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700 rounded-3xl">
                <div className="flex items-center gap-4">
                   <span className="text-2xl">{user.theme === 'light' ? '☀️' : '🌙'}</span>
                   <span className="font-bold text-slate-800 dark:text-white">Dark Mode</span>
                </div>
                <button 
                  onClick={toggleTheme}
                  className={`w-14 h-8 rounded-full transition-colors relative ${user.theme === 'dark' ? 'bg-blue-500' : 'bg-slate-300'}`}
                >
                   <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all ${user.theme === 'dark' ? 'left-7' : 'left-1'}`} />
                </button>
             </div>
          </section>

          <section className="space-y-4">
             <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest">Stats</h3>
             <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 dark:bg-slate-700 rounded-3xl text-center">
                   <p className="text-2xl font-fredoka text-blue-500">{user.xp}</p>
                   <p className="text-xs font-bold text-slate-400 uppercase">Total XP</p>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-700 rounded-3xl text-center">
                   <p className="text-2xl font-fredoka text-orange-500">{user.streak}</p>
                   <p className="text-xs font-bold text-slate-400 uppercase">Day Streak</p>
                </div>
             </div>
          </section>

          <button 
            onClick={() => {
              if(confirm("Reset all progress? This cannot be undone.")) {
                localStorage.removeItem('globey_user');
                localStorage.removeItem('globey_user_id');
                window.location.reload();
              }
            }}
            className="w-full p-4 text-red-500 font-bold border-2 border-red-50 dark:border-red-900/30 rounded-2xl hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors"
          >
            Reset All Progress
          </button>
        </div>
      </div>
    </div>
  );
};

export default Settings;
