
import React from 'react';
import { UserProfile, SkillType } from '../types';
import { BADGES, APUSH_UNITS, APUSH_QUESTS } from '../constants';
import { apiService } from '../services/apiService';

interface DashboardProps {
  user: UserProfile;
  isSyncing?: boolean;
  onStartLesson: () => void;
  onContinueLast: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, isSyncing, onStartLesson, onContinueLast }) => {
  const practicePercent = Math.min(100, Math.round((user.minutesPracticedToday / user.practiceFrequency) * 100));

  const getLastLessonInfo = () => {
    if (!user.lastLesson) return null;
    const { skill, unitId, questId } = user.lastLesson;
    if (skill === SkillType.APUSH && unitId && questId) {
      const unit = APUSH_UNITS.find(u => u.id === unitId);
      const quest = APUSH_QUESTS[unitId]?.find(q => q.id === questId);
      return {
        label: `${unit?.name || 'APUSH'}`,
        subLabel: quest?.name || 'Next Quest',
        icon: unit?.icon || '📜'
      };
    }
    return {
      label: skill,
      subLabel: 'Continue Session',
      icon: '🌍'
    };
  };

  const lastLesson = getLastLessonInfo();
  const isFirebaseConnected = apiService.isConfigured();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 pb-28 page-enter">
      {/* Header Stats */}
      <header className="sticky top-0 bg-white/90 dark:bg-slate-800/90 backdrop-blur-xl z-20 px-6 py-4 flex justify-between items-center shadow-sm border-b border-slate-100 dark:border-slate-700 transition-all">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-200">
            🌍
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-fredoka text-slate-900 dark:text-white leading-tight">Globey</span>
            <div className="flex items-center gap-1">
              <span className={`w-1.5 h-1.5 rounded-full ${isFirebaseConnected ? 'bg-green-500' : 'bg-slate-400'}`}></span>
              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">
                {isSyncing ? 'Syncing...' : (isFirebaseConnected ? 'Cloud Saved' : 'Local Only')}
              </span>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <div className="flex items-center gap-1.5 bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-900/40 px-3 py-1.5 rounded-2xl text-orange-600 dark:text-orange-400 font-bold text-sm shadow-sm transition-transform active:scale-95">
            <span className="text-base">🔥</span> {user.streak}
          </div>
          <div className="flex items-center gap-1.5 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-100 dark:border-yellow-900/40 px-3 py-1.5 rounded-2xl text-yellow-600 dark:text-yellow-400 font-bold text-sm shadow-sm transition-transform active:scale-95">
             ⭐ {user.xp}
          </div>
          <div className="flex items-center gap-1.5 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-900/40 px-3 py-1.5 rounded-2xl text-blue-600 dark:text-blue-400 font-bold text-sm shadow-sm">
             Lvl {user.level}
          </div>
        </div>
      </header>

      <main className="max-w-xl mx-auto px-6 py-8 space-y-8 transition-all">
        <section className="text-center py-4">
          <h2 className="text-3xl font-fredoka text-slate-900 dark:text-white">Welcome back, {user.name}!</h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium">
            {isFirebaseConnected ? 'Your progress is safely stored in the cloud.' : 'Progress is currently local-only.'}
          </p>
        </section>

        {/* Continue Learning Priority Card */}
        {lastLesson && (
          <section className="animate-in slide-in-from-top-4 duration-700">
            <div className="bg-white dark:bg-slate-800 p-6 rounded-[2.5rem] shadow-xl border-b-4 border-blue-100 dark:border-blue-900/50 flex items-center justify-between group">
              <div className="flex items-center gap-5">
                <div className="w-16 h-16 bg-blue-50 dark:bg-blue-900/20 rounded-3xl flex items-center justify-center text-3xl group-hover:rotate-6 transition-transform">
                  {lastLesson.icon}
                </div>
                <div>
                  <h4 className="text-sm font-black text-blue-400 dark:text-blue-500 uppercase tracking-widest mb-0.5">Pick up where you left off</h4>
                  <h3 className="text-xl font-fredoka text-slate-800 dark:text-white">{lastLesson.label}</h3>
                  <p className="text-xs text-slate-400 dark:text-slate-500 font-bold">{lastLesson.subLabel}</p>
                </div>
              </div>
              <button 
                onClick={onContinueLast}
                className="w-12 h-12 bg-blue-500 text-white rounded-full flex items-center justify-center shadow-lg shadow-blue-500/20 hover:scale-110 active:scale-90 transition-all"
              >
                ▶
              </button>
            </div>
          </section>
        )}

        <section>
          <button 
            onClick={onStartLesson}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white p-8 rounded-[3rem] shadow-2xl shadow-blue-500/30 flex flex-col items-center gap-2 transition-all active:scale-95 group"
          >
            <span className="text-4xl group-hover:scale-110 transition-transform">🚀</span>
            <span className="text-2xl font-black uppercase tracking-widest">Start Adventure</span>
            <span className="text-sm opacity-80 font-bold">Explore new regions and history</span>
          </button>
        </section>

        <section className="relative">
          <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-8 rounded-[2.5rem] shadow-2xl shadow-blue-200 dark:shadow-blue-900/20 text-white overflow-hidden">
            <div className="relative z-10">
                <h3 className="text-2xl font-fredoka mb-2">Daily Progress</h3>
                <p className="text-blue-50 mb-6 font-medium">Keep your streak alive!</p>
                <div className="flex justify-between items-end mb-3">
                  <span className="text-sm font-bold uppercase tracking-widest">
                    {user.minutesPracticedToday}m / {user.practiceFrequency}m
                  </span>
                  <span className="text-2xl font-fredoka">{practicePercent}%</span>
                </div>
                <div className="w-full bg-white/20 h-5 rounded-full p-1 backdrop-blur-sm">
                  <div 
                    className="bg-white h-full rounded-full shadow-lg transition-all duration-1000" 
                    style={{ width: `${practicePercent}%` }}
                  />
                </div>
            </div>
            <div className="absolute -bottom-10 -right-10 text-9xl opacity-10 rotate-12">⭐</div>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-fredoka text-slate-900 dark:text-white mb-6">Recent Achievements</h2>
          <div className="flex gap-4 overflow-x-auto pb-4 -mx-2 px-2 scroll-smooth no-scrollbar">
            {BADGES.map((badge) => (
              <div 
                key={badge.id}
                className={`flex-shrink-0 w-32 h-40 p-4 rounded-[2rem] flex flex-col items-center justify-center gap-3 border-2 transition-all ${
                  user.badges.includes(badge.id)
                    ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-900 shadow-lg shadow-yellow-500/10'
                    : 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 opacity-40 grayscale'
                }`}
              >
                <div className="text-4xl filter drop-shadow-md">{badge.icon}</div>
                <span className="text-[10px] font-black text-slate-800 dark:text-slate-100 text-center uppercase leading-tight">{badge.name}</span>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};

export default Dashboard;
