
import React, { useState } from 'react';
import { APUSH_UNITS, APUSH_QUESTS } from '../constants';
import { UserProfile, SkillType } from '../types';
import GlobeyMascot from './GlobeyMascot';

interface ApushPathProps {
  user: UserProfile;
  onSelectQuest: (unitId: string, questId: string) => void;
  onBack: () => void;
}

const ApushPath: React.FC<ApushPathProps> = ({ user, onSelectQuest, onBack }) => {
  const [expandedUnit, setExpandedUnit] = useState<string | null>(
    user.lastLesson?.skill === SkillType.APUSH ? user.lastLesson.unitId || null : null
  );

  const lastQuestId = user.lastLesson?.skill === SkillType.APUSH ? user.lastLesson.questId : null;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-6 pb-32 page-enter">
      <div className="max-w-xl mx-auto mt-8">
        <header className="flex items-center gap-4 mb-8">
          <button onClick={onBack} className="p-3 bg-white dark:bg-slate-800 rounded-2xl shadow-md text-slate-500 hover:text-blue-500 transition-colors">
            ←
          </button>
          <h2 className="text-3xl font-fredoka text-slate-900 dark:text-white">APUSH Mastery Path</h2>
        </header>

        <GlobeyMascot 
          message={lastQuestId 
            ? `Welcome back! You were just exploring "${Object.values(APUSH_QUESTS).flat().find(q => q.id === lastQuestId)?.name}". Ready to advance?` 
            : "The history of America is a great adventure! Tap a unit to see your 5 quests."} 
        />

        <div className="mt-12 space-y-6 relative">
          {/* Vertical connection line */}
          <div className="absolute left-[39px] top-8 bottom-8 w-1 bg-slate-200 dark:bg-slate-700 -z-0"></div>

          {APUSH_UNITS.map((unit, unitIndex) => {
            const isUnitCompleted = user.completedApushUnits.includes(unit.id);
            const isUnitExpanded = expandedUnit === unit.id;
            const quests = APUSH_QUESTS[unit.id] || [];
            
            // A unit is unlocked if it's unit 1 or the previous unit is completed
            const isUnitUnlocked = unitIndex === 0 || user.completedApushUnits.includes(APUSH_UNITS[unitIndex - 1]?.id);

            return (
              <div key={unit.id} className="space-y-4">
                <button
                  onClick={() => isUnitUnlocked && setExpandedUnit(isUnitExpanded ? null : unit.id)}
                  className={`w-full text-left p-5 rounded-[2.5rem] border-b-4 flex items-center gap-6 transition-all relative z-10 ${
                    isUnitCompleted 
                      ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                      : isUnitUnlocked
                      ? 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:scale-[1.01]'
                      : 'bg-slate-100 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-60 grayscale cursor-not-allowed'
                  } ${isUnitExpanded ? 'border-b-0 shadow-none translate-y-0.5' : 'shadow-lg'}`}
                >
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-inner ${
                    isUnitCompleted ? 'bg-green-100 text-green-600' : isUnitUnlocked ? 'bg-blue-100 text-blue-600' : 'bg-slate-200 text-slate-400'
                  }`}>
                    {isUnitCompleted ? '🏆' : unit.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-slate-800 dark:text-white">{unit.name}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                      {isUnitUnlocked ? `${quests.filter(q => user.completedApushQuests.includes(q.id)).length}/5 Quests Done` : 'Locked'}
                    </p>
                  </div>
                  <div className={`transition-transform duration-300 ${isUnitExpanded ? 'rotate-180' : ''}`}>
                    <span className="text-slate-400">▼</span>
                  </div>
                </button>

                {/* Expanded Quests */}
                {isUnitExpanded && (
                  <div className="ml-10 space-y-3 animate-in slide-in-from-top-4 duration-300">
                    {quests.map((quest, qIdx) => {
                      const isQuestCompleted = user.completedApushQuests.includes(quest.id);
                      const isQuestUnlocked = qIdx === 0 || user.completedApushQuests.includes(quests[qIdx - 1]?.id);
                      const isLast = lastQuestId === quest.id;

                      return (
                        <button
                          key={quest.id}
                          onClick={() => isQuestUnlocked && onSelectQuest(unit.id, quest.id)}
                          className={`w-full text-left p-4 rounded-3xl border-b-2 flex items-center gap-4 transition-all ${
                            isQuestCompleted
                              ? 'bg-green-100/50 dark:bg-green-900/10 border-green-200 dark:border-green-900 text-green-700 dark:text-green-400'
                              : isQuestUnlocked
                              ? 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-blue-50 dark:hover:bg-blue-900/10'
                              : 'bg-slate-50 dark:bg-slate-900/50 border-slate-100 dark:border-slate-800 text-slate-400 opacity-50 grayscale cursor-not-allowed'
                          } ${isLast ? 'ring-2 ring-blue-500' : ''}`}
                        >
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${
                            isQuestCompleted ? 'bg-green-500 text-white' : isQuestUnlocked ? 'bg-blue-500 text-white' : 'bg-slate-300 text-slate-50'
                          }`}>
                            {isQuestCompleted ? '✓' : qIdx + 1}
                          </div>
                          <div className="flex-1">
                            <span className="text-sm font-black">{quest.name}</span>
                            {isLast && <span className="ml-2 text-[8px] font-black uppercase bg-blue-500 text-white px-1.5 py-0.5 rounded-full">Recent</span>}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ApushPath;
