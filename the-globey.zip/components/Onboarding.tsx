
import React, { useState } from 'react';
import GlobeyMascot from './GlobeyMascot';
import { UserProfile, LearningGoal, SkillType } from '../types';

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [goal, setGoal] = useState<LearningGoal>(LearningGoal.CASUAL);
  const [skills, setSkills] = useState<SkillType[]>([]);
  const [frequency, setFrequency] = useState(10);

  const steps = [
    { message: "Welcome explorer! I'm Globey. What should I call you?", field: 'name' },
    { message: `Wonderful! So ${name}, what brings you to our global adventure?`, field: 'goal' },
    { message: "Exciting! What parts of our world are you most curious about?", field: 'skills' },
    { message: "Last step! How much time can you explore with me each day?", field: 'frequency' }
  ];

  const toggleSkill = (skill: SkillType) => {
    if (skills.includes(skill)) {
      setSkills(skills.filter(s => s !== skill));
    } else {
      setSkills([...skills, skill]);
    }
  };

  const next = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      // Fix: Added missing 'completedApushQuests' property to satisfy the UserProfile interface.
      onComplete({
        name,
        goal,
        skillInterests: skills,
        practiceFrequency: frequency,
        minutesPracticedToday: 0,
        xp: 0,
        streak: 1,
        level: 1,
        lastActive: new Date().toISOString(),
        unlockedRegions: ['balkans'],
        completedApushUnits: [],
        completedApushQuests: [],
        badges: [],
        theme: 'light'
      });
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 bg-slate-50 dark:bg-slate-900 page-enter">
      <div className="w-full max-w-lg space-y-10">
        <GlobeyMascot message={steps[step].message} emotion={step === 3 ? 'happy' : 'neutral'} />
        
        <div className="bg-white dark:bg-slate-800 p-8 md:p-10 rounded-[3rem] shadow-2xl shadow-blue-900/10 border border-slate-50 dark:border-slate-700 transition-all">
          <div key={step} className="animate-in fade-in slide-in-from-right-10 duration-500">
            {step === 0 && (
              <div className="space-y-6">
                <input
                  type="text"
                  className="w-full p-6 text-2xl border-b-4 border-blue-400 focus:outline-none focus:border-blue-600 rounded-2xl bg-slate-50 dark:bg-slate-700 dark:text-white text-center font-fredoka text-slate-800"
                  placeholder="Type your name..."
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && name && next()}
                  autoFocus
                />
                <button 
                  onClick={next} 
                  disabled={!name}
                  className="w-full py-5 bg-blue-500 text-white rounded-[2rem] font-black text-xl shadow-xl shadow-blue-500/30 hover:bg-blue-600 disabled:opacity-30 transition-all active:scale-95"
                >
                  Continue
                </button>
              </div>
            )}

            {step === 1 && (
              <div className="grid grid-cols-1 gap-4">
                {Object.values(LearningGoal).map((g) => (
                  <button
                    key={g}
                    onClick={() => { setGoal(g); next(); }}
                    className="p-6 text-xl font-bold rounded-3xl bg-slate-50 dark:bg-slate-700 border-b-4 border-slate-200 dark:border-slate-600 hover:border-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all text-slate-800 dark:text-slate-100 capitalize active:translate-y-1 active:border-b-0"
                  >
                    {g}
                  </button>
                ))}
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 gap-3">
                  {Object.values(SkillType).map((s) => (
                    <button
                      key={s}
                      onClick={() => toggleSkill(s)}
                      className={`p-6 text-xl font-bold rounded-3xl transition-all border-b-4 ${
                        skills.includes(s) 
                          ? 'bg-blue-500 text-white border-blue-700 shadow-xl shadow-blue-500/20' 
                          : 'bg-slate-50 dark:bg-slate-700 text-slate-800 dark:text-slate-100 border-slate-200 dark:border-slate-600 hover:border-blue-200'
                      } active:translate-y-1 active:border-b-0`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
                <button
                  disabled={skills.length === 0}
                  onClick={next}
                  className="w-full p-6 mt-4 bg-green-500 text-white font-black text-xl rounded-[2rem] shadow-xl shadow-green-500/30 hover:bg-green-600 disabled:opacity-30 transition-all active:scale-95"
                >
                  Confirm & Launch!
                </button>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-10">
                <div className="px-4">
                    <input
                      type="range"
                      min="5"
                      max="60"
                      step="5"
                      value={frequency}
                      onChange={(e) => setFrequency(parseInt(e.target.value))}
                      className="w-full h-4 bg-slate-100 dark:bg-slate-700 rounded-full appearance-none cursor-pointer accent-blue-500"
                    />
                </div>
                <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-3xl border border-blue-100 dark:border-blue-800 text-center">
                   <p className="text-4xl font-fredoka text-blue-600 dark:text-blue-400 mb-1">{frequency}</p>
                   <p className="text-sm font-bold text-blue-400 uppercase tracking-widest">minutes per day</p>
                </div>
                <button
                  onClick={next}
                  className="w-full p-6 bg-blue-600 text-white font-black text-xl rounded-[2rem] shadow-2xl shadow-blue-600/40 hover:bg-blue-700 transition-all active:scale-95"
                >
                  Start Adventure
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Onboarding;
