
import React, { useState } from 'react';
import { SkillType } from '../types';
import GlobeyMascot from './GlobeyMascot';

interface SubjectPickerProps {
  onSelect: (skill: SkillType) => void;
  onBack: () => void;
}

const SubjectPicker: React.FC<SubjectPickerProps> = ({ onSelect, onBack }) => {
  const [category, setCategory] = useState<'GEOGRAPHY' | 'HISTORY' | null>(null);

  const subjects = {
    GEOGRAPHY: [
      { id: SkillType.FLAGS, name: 'Flags', icon: '🚩', color: 'bg-red-100 text-red-600' },
      { id: SkillType.CAPITALS, name: 'Capitals', icon: '🏛️', color: 'bg-blue-100 text-blue-600' },
      { id: SkillType.FACTS, name: 'Country Facts', icon: '🌍', color: 'bg-green-100 text-green-600' }
    ],
    HISTORY: [
      { id: SkillType.APUSH, name: 'APUSH (US History)', icon: '🦅', color: 'bg-amber-100 text-amber-700' },
      { id: SkillType.APWH, name: 'AP World History', icon: '📜', color: 'bg-purple-100 text-purple-600' }
    ]
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-6 pb-32 page-enter">
      <div className="max-w-xl mx-auto space-y-10 mt-8">
        <GlobeyMascot 
          message={category ? `Great choice! Which ${category.toLowerCase()} topic interests you?` : "Hello explorer! What would you like to master today?"} 
        />

        <div className="space-y-6">
          {!category ? (
            <div className="grid grid-cols-1 gap-4">
              <button 
                onClick={() => setCategory('GEOGRAPHY')}
                className="group relative bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border-b-4 border-blue-200 dark:border-blue-900 shadow-xl flex items-center gap-6 transition-all hover:scale-[1.02] active:translate-y-1 active:border-b-0"
              >
                <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/40 rounded-3xl flex items-center justify-center text-4xl group-hover:rotate-12 transition-transform">🌍</div>
                <div className="text-left">
                  <h3 className="text-2xl font-fredoka text-slate-900 dark:text-white">Geography</h3>
                  <p className="text-slate-500 dark:text-slate-400 font-medium">Explore flags, capitals, and nations.</p>
                </div>
              </button>

              <button 
                onClick={() => setCategory('HISTORY')}
                className="group relative bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border-b-4 border-amber-200 dark:border-amber-900 shadow-xl flex items-center gap-6 transition-all hover:scale-[1.02] active:translate-y-1 active:border-b-0"
              >
                <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/40 rounded-3xl flex items-center justify-center text-4xl group-hover:rotate-12 transition-transform">📜</div>
                <div className="text-left">
                  <h3 className="text-2xl font-fredoka text-slate-900 dark:text-white">History</h3>
                  <p className="text-slate-500 dark:text-slate-400 font-medium">Dive into AP US and World History.</p>
                </div>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <button onClick={() => setCategory(null)} className="text-blue-500 font-bold flex items-center gap-2">
                   ← Back to Categories
                </button>
              </div>
              <div className="grid grid-cols-1 gap-4">
                {subjects[category].map((item) => (
                  <button 
                    key={item.id}
                    onClick={() => onSelect(item.id)}
                    className="group bg-white dark:bg-slate-800 p-6 rounded-[2rem] border-b-4 border-slate-100 dark:border-slate-700 shadow-lg flex items-center gap-5 transition-all active:translate-y-1 active:border-b-0"
                  >
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl ${item.color.split(' ')[0]} dark:bg-slate-700`}>{item.icon}</div>
                    <span className="text-xl font-bold text-slate-800 dark:text-white">{item.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SubjectPicker;
