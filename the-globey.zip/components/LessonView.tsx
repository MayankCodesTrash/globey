
import React, { useState } from 'react';
import { LessonData, SkillType } from '../types';
import GlobeyMascot from './GlobeyMascot';
import { getPersonalizedHint } from '../services/geminiService';

interface LessonViewProps {
  lesson: LessonData;
  onFinish: (score: number) => void;
  onExit: () => void;
}

const LessonView: React.FC<LessonViewProps> = ({ lesson, onFinish, onExit }) => {
  const [view, setView] = useState<'CONTENT' | 'QUIZ' | 'FEEDBACK'>('CONTENT');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [hint, setHint] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const currentQuestion = lesson.quiz[currentQuestionIndex];

  const handleAnswer = async (option: string) => {
    setSelectedOption(option);
    const isCorrect = option === currentQuestion.correctAnswer;
    
    if (isCorrect) {
      setScore(score + 1);
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 2000);
    } else {
      setIsProcessing(true);
      const newHint = await getPersonalizedHint(currentQuestion.question, option, currentQuestion.correctAnswer);
      setHint(newHint);
      setIsProcessing(false);
    }
    setView('FEEDBACK');
  };

  const nextStep = () => {
    if (currentQuestionIndex < lesson.quiz.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedOption(null);
      setHint(null);
      setView('QUIZ');
    } else {
      onFinish(score);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col relative overflow-hidden page-enter pb-32">
      {/* Confetti Animation */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <div 
              key={i} 
              className="confetti-piece"
              style={{
                left: `${Math.random() * 100}%`,
                backgroundColor: ['#3B82F6', '#22C55E', '#EAB308', '#F97316'][Math.floor(Math.random() * 4)],
                animationDelay: `${Math.random() * 0.5}s`,
                width: `${Math.random() * 10 + 5}px`,
                height: `${Math.random() * 10 + 5}px`
              }}
            />
          ))}
        </div>
      )}

      <header className="px-6 py-6 flex items-center justify-between z-10">
        <button 
          onClick={onExit}
          className="w-12 h-12 flex items-center justify-center bg-white rounded-2xl shadow-lg shadow-slate-200 text-slate-400 hover:text-red-500 transition-colors"
        >
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
        
        <div className="flex-1 max-w-xs mx-6">
            <div className="flex justify-between items-center mb-2">
               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                 Level {Math.min(10, currentQuestionIndex + 1)}/10
               </span>
               <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest">
                 Progress: {Math.round(((currentQuestionIndex) / lesson.quiz.length) * 100)}%
               </span>
            </div>
            <div className="bg-slate-200 h-2.5 rounded-full overflow-hidden p-0.5">
              <div 
                className="bg-blue-500 h-full rounded-full transition-all duration-1000 shadow-[0_0_10px_rgba(59,130,246,0.5)]" 
                style={{ width: `${((currentQuestionIndex + (view === 'CONTENT' ? 0 : 1)) / (lesson.quiz.length + 1)) * 100}%` }}
              />
            </div>
        </div>

        <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-xl shadow-lg shadow-blue-100">
           {lesson.skillType === SkillType.FLAGS ? '🚩' : '🗺️'}
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center px-6 pb-12 w-full max-w-xl mx-auto z-10">
        {view === 'CONTENT' && (
          <div className="space-y-10 w-full animate-in fade-in zoom-in slide-in-from-bottom-10 duration-700">
            <GlobeyMascot message={lesson.intro} />
            <div className="bg-white p-8 rounded-[3rem] shadow-2xl shadow-blue-900/5 border border-slate-50 space-y-8">
              <div>
                 <h3 className="text-2xl font-fredoka text-slate-900 mb-2">Explorer's Guide</h3>
                 <p className="text-slate-500 font-medium">Review these key facts before the challenge!</p>
              </div>
              <ul className="space-y-4">
                {lesson.keyFacts.map((fact, idx) => (
                  <li key={idx} className="flex gap-4 p-4 bg-slate-50 rounded-3xl border border-white">
                    <span className="text-xl">📍</span>
                    <p className="text-slate-700 font-bold leading-relaxed">{fact}</p>
                  </li>
                ))}
              </ul>
              <button 
                onClick={() => setView('QUIZ')}
                className="w-full bg-blue-500 text-white p-6 rounded-[2rem] font-black text-xl shadow-xl shadow-blue-500/30 hover:bg-blue-600 active:translate-y-1 transition-all"
              >
                Start Quiz!
              </button>
            </div>
          </div>
        )}

        {view === 'QUIZ' && (
          <div className="w-full space-y-10 animate-in slide-in-from-right duration-500">
            <div className="text-center">
               <p className="text-xs font-black text-blue-500 uppercase tracking-widest mb-3">Question {currentQuestionIndex + 1}</p>
               <h2 className="text-3xl font-fredoka text-slate-900 px-2">{currentQuestion.question}</h2>
            </div>
            
            {/* Flag Display logic */}
            {currentQuestion.countryCode && (
              <div className="flex justify-center p-4 bg-white rounded-3xl shadow-lg border-2 border-slate-100">
                <img 
                  src={`https://flagcdn.com/w320/${currentQuestion.countryCode}.png`} 
                  alt="Flag to identify" 
                  className="max-h-32 object-contain rounded-lg shadow-sm"
                  onError={(e) => (e.target as HTMLImageElement).style.display = 'none'}
                />
              </div>
            )}

            <div className="grid grid-cols-1 gap-4">
              {currentQuestion.options.map((option, idx) => (
                <button
                  key={option}
                  onClick={() => handleAnswer(option)}
                  style={{ animationDelay: `${idx * 0.1}s` }}
                  className="bg-white p-6 rounded-[2rem] text-xl font-bold text-slate-800 border-b-4 border-slate-200 hover:border-blue-300 shadow-xl shadow-slate-900/5 transition-all text-left active:translate-y-1 active:border-b-0"
                >
                  <span className="inline-block w-10 h-10 bg-slate-50 rounded-xl text-center leading-10 text-slate-400 mr-4 text-sm font-black">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  {option}
                </button>
              ))}
            </div>
          </div>
        )}

        {view === 'FEEDBACK' && (
          <div className="w-full space-y-8 animate-in zoom-in duration-500">
            <GlobeyMascot 
              isThinking={isProcessing}
              emotion={selectedOption === currentQuestion.correctAnswer ? 'happy' : 'oops'}
              message={
                selectedOption === currentQuestion.correctAnswer 
                ? "Incredible! You're a geography genius!" 
                : (hint || "Geography can be tricky! Look at this hint...")
              } 
            />
            
            <div className={`p-8 rounded-[3rem] border-4 shadow-2xl relative overflow-hidden ${
              selectedOption === currentQuestion.correctAnswer 
                ? 'bg-white border-green-500 shadow-green-500/10' 
                : 'bg-white border-orange-500 shadow-orange-500/10'
            }`}>
              <div className="flex items-start gap-5 mb-6">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-lg ${
                  selectedOption === currentQuestion.correctAnswer ? 'bg-green-100' : 'bg-orange-100'
                }`}>
                  {selectedOption === currentQuestion.correctAnswer ? '✅' : '⚡'}
                </div>
                <div className="flex-1">
                  <h4 className={`text-2xl font-fredoka ${
                    selectedOption === currentQuestion.correctAnswer ? 'text-green-600' : 'text-orange-600'
                  }`}>
                    {selectedOption === currentQuestion.correctAnswer ? 'Perfecto!' : 'So Close!'}
                  </h4>
                  <p className="text-slate-600 font-medium">
                    The correct answer is <span className="font-black text-slate-900 underline decoration-blue-500/30 underline-offset-4">{currentQuestion.correctAnswer}</span>
                  </p>
                </div>
              </div>

              <div className="p-5 bg-slate-50 rounded-3xl border border-slate-100 mb-8">
                <p className="text-slate-700 font-bold italic leading-relaxed">"{currentQuestion.explanation}"</p>
              </div>
              
              <button 
                onClick={nextStep}
                disabled={isProcessing}
                className={`w-full p-6 rounded-[2rem] font-black text-xl shadow-xl transition-all active:scale-95 disabled:opacity-50 ${
                  selectedOption === currentQuestion.correctAnswer 
                    ? 'bg-green-500 text-white shadow-green-500/30 hover:bg-green-600' 
                    : 'bg-blue-500 text-white shadow-blue-500/30 hover:bg-blue-600'
                }`}
              >
                {currentQuestionIndex < lesson.quiz.length - 1 ? 'Continue' : 'Finish Adventure'}
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default LessonView;
